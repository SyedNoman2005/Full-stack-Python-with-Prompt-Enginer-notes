import oracledb as orc

def recordselect():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        while True:
            accno = input("Enter Account Number (11 digits): ")
            if not accno.isdigit() or len(accno) != 11:
                print("❌ Invalid Account Number. It must be 11 digits.")
                continue
            accno = int(accno)

            # Check if account exists
            cur.execute("SELECT * FROM Vision_Banking_Information_System WHERE ACNO = :1", [accno])
            result = cur.fetchone()
            if result:
                print("\n✅ Account Found. Details:")
                print("-----------------------------------------------")
                for col, val in zip([desc[0] for desc in cur.description], result):
                    print(f"{col:<10}: {val}")
                print("-----------------------------------------------")
                break
            else:
                print("❌ Account not found. Try again.")
    except orc.DatabaseError as db:
        print("❌ Problem in Oracle DB:", db)
