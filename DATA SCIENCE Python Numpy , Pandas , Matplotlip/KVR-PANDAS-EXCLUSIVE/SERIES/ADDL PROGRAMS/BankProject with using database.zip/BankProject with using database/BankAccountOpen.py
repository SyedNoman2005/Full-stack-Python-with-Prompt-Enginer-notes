# BankAccountOpen.py
import oracledb as orc
import random
from BankExcept import *

def generate_acno():
    return str(random.randint(10**10, 10**11 - 1))

def openaccount():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        # Try to create table if not exists
        try:
            cur.execute("""
                CREATE TABLE Vision_Banking_Information_System (
                    ACNO    VARCHAR2(11) PRIMARY KEY,
                    CNAME   VARCHAR2(20) NOT NULL,
                    BAL     NUMBER(10,2) NOT NULL,
                    PIN     NUMBER(4),
                    ADCNO   VARCHAR2(12),
                    PAN     VARCHAR2(10),
                    BNAME   VARCHAR2(30)
                )
            """)
            print("✅ Table created.")
        except orc.DatabaseError:
            pass

        # Generate unique account number
        while True:
            acno = generate_acno()
            cur.execute("SELECT 1 FROM Vision_Banking_Information_System WHERE ACNO = :1", [acno])
            if not cur.fetchone():
                break

        # Customer Name Validation
        while True:
            try:
                cname = input("Enter Customer Name: ").strip()
                if cname == "":
                    raise ZeroNameLengthError("Name cannot be empty.")
                if not cname.replace(" ", "").isalpha():
                    raise InvalidNameError("Name should only contain alphabets.")
                break
            except (InvalidNameError, ZeroNameLengthError) as err:
                print("❌", err)

        # Balance Validation
        while True:
            try:
                bal = float(input("Enter Initial Balance: "))
                break
            except:
                print("❌ Invalid balance amount.")

        # Aadhar Validation
        while True:
            adcno = input("Enter Aadhar Number (12 digits): ").strip()
            if not adcno.isdigit() or len(adcno) != 12:
                print("❌ Invalid Aadhar Number.")
                continue

            cur.execute("SELECT 1 FROM Vision_Banking_Information_System WHERE ADCNO = :1", [adcno])
            if cur.fetchone():
                print("❌ Aadhar already exists.")
                continue
            break

        # PAN Validation
        def is_valid_pan(pan):
            return (
                len(pan) == 10 and
                pan[:5].isalpha() and
                pan[5:9].isdigit() and
                pan[9].isalpha() and
                pan.isupper()
            )

        while True:
            pan = input("Enter PAN Number: ").strip().upper()
            if not is_valid_pan(pan):
                print("❌ Invalid PAN format.")
                continue

            cur.execute("SELECT 1 FROM Vision_Banking_Information_System WHERE PAN = :1", [pan])
            if cur.fetchone():
                print("❌ PAN already exists.")
                continue
            break

        # Branch Name
        while True:
            bname = input("Enter Branch Name: ").strip()
            if bname:
                break
            else:
                print("❌ Branch Name cannot be empty.")

        # Insert record with NULL PIN
        cur.execute("""
            INSERT INTO Vision_Banking_Information_System 
            VALUES (:1, :2, :3, NULL, :4, :5, :6)
        """, (acno, cname, bal, adcno, pan, bname))

        con.commit()
        print("\n✅ Account created successfully!")
        print("🆔 Account Number :", acno)
        print("✅ Thank you for using for this program.")

        cur.close()
        con.close()

    except orc.DatabaseError as db:
        print("❌ Oracle DB Error:", db)


