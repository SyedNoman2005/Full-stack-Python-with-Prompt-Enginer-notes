# BankMenu.py

from BankAccountOpen import openaccount
from BankPinGenerateUpdate import pingenerate, pinupdate
from BankDeposit import deposit_amount
from BankWithDraw import withdraw_amount
from BankSearchCustomer import recordselect
from BankViewCustomers import recordSingleCustomer, read_all_accounts
from BankCloseAccount import close_bank_account
from BankFundTransfer import bankTransfer  # ✅ Added import

def BankMenu():
    while True:
        print("=" * 50)
        print("🏦 BANK INFORMATION SYSTEM MENU")
        print("=" * 50)
        print("1. OPEN ACCOUNT")
        print("2. PIN GENERATION")
        print("3. PIN CHANGE")
        print("4. DEPOSIT")
        print("5. WITHDRAW")
        print("6. FUNDS TRANSFER")
        print("7. SEARCH FOR CUSTOMER")
        print("8. VIEW SINGLE CUSTOMER DETAILS")
        print("9. VIEW ALL CUSTOMERS")
        print("10. CLOSE ACCOUNT")
        print("11. EXIT")
        print("=" * 50)

        choice = input("Enter your choice (1-11): ").strip()

        if choice == '1':
            openaccount()
        elif choice == '2':
            pingenerate()
        elif choice == '3':
            pinupdate()
        elif choice == '4':
            deposit_amount()
        elif choice == '5':
            withdraw_amount()
        elif choice == '6':
            bankTransfer()
        elif choice == '7':
            recordselect()
        elif choice == '8':
            recordSingleCustomer()
        elif choice == '9':
            read_all_accounts()
        elif choice == '10':
            close_bank_account()
        elif choice == '11':
            print("🚪 Exiting the Bank System. Thank you!")
            break
        else:
            print("❌ Invalid choice. Please enter a number between 1 and 11.")

# Main Program
BankMenu()
