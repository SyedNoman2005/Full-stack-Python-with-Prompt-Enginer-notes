import oracledb as orc

def deposit_amount():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        # Step 1: Account Number Validation
        accno = input("🔑 Enter Your Account Number (11 digits): ")
        if not accno.isdigit() or len(accno) != 11:
            print(" Invalid Account Number.")
            return
        accno = int(accno)

        # Step 2: PIN Validation
        entered_pin = input("🔐 Enter Your 4-digit PIN: ")
        if not entered_pin.isdigit() or len(entered_pin) != 4:
            print(" Invalid PIN format.")
            return
        entered_pin = int(entered_pin)

        # Step 3: Fetch current balance and verify credentials
        cur.execute("""
            SELECT BAL FROM Vision_Banking_Information_System
            WHERE ACNO = :1 AND PIN = :2
        """, [accno, entered_pin])

        result = cur.fetchone()

        if not result:
            print(" Account not found or incorrect PIN.")
            return

        current_balance = result[0]
        print(f"💰 Current Balance: ₹{current_balance:.2f}")

        # Step 4: Take deposit amount
        try:
            amount = float(input("💵 Enter deposit amount: "))
            if amount <= 0:
                print(" Deposit amount must be greater than 0.")
                return
        except ValueError:
            print(" Please enter a valid numeric amount.")
            return

        # Step 5: Update balance
        new_balance = current_balance + amount
        cur.execute("""
            UPDATE Vision_Banking_Information_System
            SET BAL = :1 WHERE ACNO = :2
        """, [new_balance, accno])
        con.commit()

        print(f"✅ ₹{amount:.2f} deposited successfully!")
        print(f"🧾 Updated Balance: ₹{new_balance:.2f}")

    except orc.DatabaseError as db:
        print("❌ Oracle DB Error:", db)

    finally:
        if con:
            con.close()


