import oracledb as orc
from BankExcept import InSufficientFundError


def withdraw_amount():
    con = None
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        # Step 1: Account Number Validation
        accno = input("🔑 Enter Your Account Number (11 digits): ")
        if not accno.isdigit() or len(accno) != 11:
            print("❌ Invalid Account Number.")
            return
        accno = int(accno)

        # Step 2: PIN Validation
        entered_pin = input("🔐 Enter Your 4-digit PIN: ")
        if not entered_pin.isdigit() or len(entered_pin) != 4:
            print("❌ Invalid PIN format.")
            return
        entered_pin = int(entered_pin)

        # Step 3: Fetch current balance and verify credentials
        cur.execute("""
            SELECT BAL FROM Vision_Banking_Information_System
            WHERE ACNO = :1 AND PIN = :2
        """, [accno, entered_pin])

        result = cur.fetchone()

        if not result:
            print("❌ Account not found or incorrect PIN.")
            return

        current_balance = result[0]
        print(f"💰 Current Balance: ₹{current_balance:.2f}")

        # Step 4: Take withdraw amount
        try:
            amount = float(input("💵 Enter withdraw amount: "))
            if amount <= 0:
                print("❌ Withdrawal amount must be positive.")
                return

            MIN_BALANCE = 500  # Minimum required balance
            if current_balance - amount < MIN_BALANCE:
                raise InSufficientFundError("Insufficient funds to maintain minimum balance")

        except ValueError:
            print("❌ Please enter a valid numeric amount.")
            return
        except InSufficientFundError as e:
            print(f"❌ {str(e)}")
            return

        # Step 5: Update balance
        new_balance = current_balance - amount
        cur.execute("""
            UPDATE Vision_Banking_Information_System
            SET BAL = :1 WHERE ACNO = :2
        """, [new_balance, accno])
        con.commit()

        print(f"✅ ₹{amount:.2f} debited successfully!")
        print(f"🧾 Updated Balance: ₹{new_balance:.2f}")

    except orc.DatabaseError as db:
        print("❌ Oracle DB Error:", db)
        if con:
            con.rollback()

    finally:
        if con:
            con.close()


