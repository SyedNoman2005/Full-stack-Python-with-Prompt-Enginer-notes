import oracledb as orc

def bankTransfer():
    con = None
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        accno_debit = input("Enter account number to Debit: ")
        if not accno_debit.isdigit() or len(accno_debit) != 11:
            print("Invalid Debit Account Number.")
            return

        pin = input("Enter your PIN: ")
        if not pin.isdigit() or len(pin) != 4:
            print("Invalid PIN.")
            return

        accno_credit = input("Enter account number to Credit: ")
        if not accno_credit.isdigit() or len(accno_credit) != 11:
            print("Invalid Credit Account Number.")
            return

        amount = input("Enter amount to transfer: ")
        if not amount.isdigit() or int(amount) <= 0:
            print("Invalid amount.")
            return

        accno_debit = int(accno_debit)
        accno_credit = int(accno_credit)
        pin = int(pin)
        amount = int(amount)

        # Verify debit account and PIN
        cur.execute("""
            SELECT BAL FROM Vision_Banking_Information_System
            WHERE ACNO = :1 AND PIN = :2
        """, [accno_debit, pin])
        result = cur.fetchone()

        if result is None:
            print("Invalid debit account number or PIN.")
            return

        current_balance = result[0]
        if current_balance < amount:
            print("Insufficient balance.")
            return

        # Verify credit account exists
        cur.execute("""
            SELECT 1 FROM Vision_Banking_Information_System
            WHERE ACNO = :1
        """, [accno_credit])
        if cur.fetchone() is None:
            print("Credit account does not exist.")
            return

        # Perform transfer
        cur.execute("""
            UPDATE Vision_Banking_Information_System
            SET BAL = BAL - :1 WHERE ACNO = :2
        """, [amount, accno_debit])

        cur.execute("""
            UPDATE Vision_Banking_Information_System
            SET BAL = BAL + :1 WHERE ACNO = :2
        """, [amount, accno_credit])

        con.commit()
        print("Amount transferred successfully.")

    except Exception as e:
        if con:
            con.rollback()
        print("Error:", e)

    finally:
        if con:
            con.close()
