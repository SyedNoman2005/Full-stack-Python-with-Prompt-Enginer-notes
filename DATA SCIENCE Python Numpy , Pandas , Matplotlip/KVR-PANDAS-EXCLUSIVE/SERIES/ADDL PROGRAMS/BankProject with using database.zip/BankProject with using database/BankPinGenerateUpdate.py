# BankPinGenerateUpdate.py
import oracledb as orc
import random

def pingenerate():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        accno = input("Enter Account Number to generate PIN: ")
        if not accno.isdigit():
            print(" Invalid Account Number.")
            return

        accno = int(accno)
        cur.execute("SELECT ACNO FROM Vision_Banking_Information_System WHERE ACNO = :1", [accno])
        if not cur.fetchone():
            print(" Account not found.")
            return

        pin = random.randint(1000, 9999)
        cur.execute("UPDATE Vision_Banking_Information_System SET PIN = :1 WHERE ACNO = :2", [pin, accno])
        con.commit()
        print(" PIN Generated Successfully!")
        print(" Your New PIN is:", pin)

        con.close()

    except orc.DatabaseError as db:
        print(" Oracle DB Error:", db)

def pinupdate():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        accno = input("Enter Account Number to update PIN: ")
        if not accno.isdigit():
            print(" Invalid Account Number.")
            return
        accno = int(accno)

        old_pin = input("Enter Current PIN: ")
        if not old_pin.isdigit():
            print(" Invalid PIN format.")
            return

        cur.execute("SELECT PIN FROM Vision_Banking_Information_System WHERE ACNO = :1", [accno])
        result = cur.fetchone()
        if not result:
            print(" Account not found.")
            return

        if int(old_pin) != result[0]:
            print(" Incorrect current PIN.")
            return

        new_pin = random.randint(1000, 9999)
        cur.execute("UPDATE Vision_Banking_Information_System SET PIN = :1 WHERE ACNO = :2", [new_pin, accno])
        con.commit()

        print(" PIN Updated Successfully!")
        print(" Your New PIN is:", new_pin)

        con.close()

    except orc.DatabaseError as db:
        print(" Oracle DB Error:", db)