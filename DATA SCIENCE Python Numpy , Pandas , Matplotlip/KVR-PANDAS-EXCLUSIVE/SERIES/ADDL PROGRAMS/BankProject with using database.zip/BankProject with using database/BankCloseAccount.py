import oracledb as orc

def close_bank_account():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        acno = input(" Enter Account Number to Close: ")
        if not acno.isdigit() or len(acno) != 11:
            print(" Invalid Account Number. It must be 11 digits.")
            return
        acno = int(acno)

        cur.execute("DELETE FROM Vision_Banking_Information_System WHERE ACNO = :1", [acno])
        con.commit()

        if cur.rowcount > 0:
            print(f" Account {acno} closed successfully.")
        else:
            print(" Account number does not exist.")

    except orc.DatabaseError as db:
        print(" Oracle DB Error:", db)

    finally:
        if con:
            con.close()


