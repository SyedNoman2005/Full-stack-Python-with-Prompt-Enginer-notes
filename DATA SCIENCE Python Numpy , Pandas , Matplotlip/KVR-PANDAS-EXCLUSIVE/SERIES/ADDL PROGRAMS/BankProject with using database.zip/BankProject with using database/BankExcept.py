class InvalidNameError(Exception):pass
class SpaceError(BaseException):pass
class ZeroNameLengthError(Exception):pass
class ValueError(BaseException):pass
class InSufficientFundError(Exception):pass
class InvalidError(Exception):pass