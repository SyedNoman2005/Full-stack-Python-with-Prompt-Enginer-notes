# OracleSelectRecordsEx2.py
import oracledb as orc


def recordSingleCustomer():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()

        while True:
            accno = input("Enter Account Number (11 digits): ")
            if not accno.isdigit() or len(accno) != 11:
                print("❌ Invalid Account Number. It must be 11 digits.")
                continue
            accno = int(accno)

            # Check if account exists
            cur.execute("SELECT * FROM Vision_Banking_Information_System WHERE ACNO = :1", [accno])
            result = cur.fetchone()
            if result:
                print("\n✅ Account Found. Details:")
                print("-----------------------------------------------")
                for col, val in zip([desc[0] for desc in cur.description], result):
                    print(f"{col:<10}: {val}")
                print("-----------------------------------------------")
                break
            else:
                print("❌ Account not found. Try again.")

        # Ask if user wants to see all accounts
        cont = input("\nDo you want to view all customer accounts? (yes/no): ").strip().lower()
        if cont == 'yes':
            read_all_accounts()

    except orc.DatabaseError as db:
        print("❌ Problem in Oracle DB:", db)


def read_all_accounts():
    try:
        con = orc.connect("system/tiger@127.0.0.1/orcl")
        cur = con.cursor()
        cur.execute("SELECT * FROM Vision_Banking_Information_System")

        print("\n---------- CUSTOMER ACCOUNTS ----------")
        for col in [col[0] for col in cur.description]:
            print(f"{col:<15}", end="\t")
        print("\n" + "-" * 60)

        for row in cur.fetchall():
            for val in row:
                print(f"{str(val):<15}", end="\t")
            print()
        print("-" * 60)

        con.close()

    except orc.DatabaseError as db:
        print("❌ Oracle DB Error:", db)




